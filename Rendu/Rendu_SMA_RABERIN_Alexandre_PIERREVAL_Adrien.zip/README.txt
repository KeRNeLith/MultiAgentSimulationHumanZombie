Le rendu du projet contient les �l�ments suivants :

Un dossier Executable :
Il contient un version compil� et packag� de l'application finale du projet de SMA (zombifier-1.0.0.jar)
Il s'agit de l'application graphique et non console.

Un dossier Javadoc :
Il contient la documentation du code source g�n�r�e via Maven.
Le fichier permettant d'ouvrir le site de la javadoc est le suivant :
./Javadoc/site/apidocs/index.html

Un dossier Rapports :
Il contient nos 2 rapports personnels sur les outils Maven et IntelliJ.
Il contient aussi le rapport du projet.

Un dossier Source Projet :
Il contient les sources ayant permit de compiler le projet. 
Le dossier contient le fichier qui permet d'ouvrir le projet via le pom.xml (g�n�r� par Maven).

Un dossier Tests Unitaires :
Il contient les rapports de tests unitaires effectu�s sur le code source du projet via le plugin surefire de Maven.